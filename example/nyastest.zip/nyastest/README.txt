This is a example to demonstrate how to use "nyaszip" to build a multi-password zip file.

Files "nyaszip.toml" be distributed everywhere are the configuration of "nyaszip", see more infomation in these files.

Drag the whole directory "nyastest" into "nyaszip.exe", then get the zip file "nyastest.zip".

The password of the file "nyastest/dir2/A.txt" in "nyastest.zip" is "AAA".